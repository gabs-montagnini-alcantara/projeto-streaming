import os
import boto3
import json
import random
from datetime import datetime, timezone

def lambda_handler(event, context):
    kinesis = boto3.client('kinesis')
    stream_name = os.environ['KINESIS_STREAM']

    nomes = [
        "Ana", "Bruno", "Carlos", "Diana", "Eduardo",
        "Fernanda", "Gabriel", "Helena", "Igor", "Julia",
        "Kleber", "Larissa", "Marcos", "Natália", "Otávio",
        "Paula", "Quintino", "Rafaela", "Sérgio", "Tatiane"
    ]

    nome_escolhido = random.choice(nomes)
    valor = round(random.uniform(0, 100000), 2)
    timestamp = datetime.now(timezone.utc).isoformat()

    data = {
        "nome": nome_escolhido,
        "valor": valor,
        "timestamp": timestamp
    }

    response = kinesis.put_record(
        StreamName=stream_name,
        Data=json.dumps(data),
        PartitionKey="1"
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Enviado com sucesso')
    }
