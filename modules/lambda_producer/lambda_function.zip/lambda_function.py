import os
import boto3
import json
import random
from datetime import datetime, timezone

def lambda_handler(event, context):
    kinesis = boto3.client('kinesis')
    stream_name = os.environ['KINESIS_STREAM']

    nomes = [
        "Ana", "Bruno", "Carlos", "Diana", "Eduardo",
        "Fernanda", "Gabriel", "Helena", "Igor", "Julia",
        "Kleber", "Larissa", "Marcos", "Natália", "Otávio",
        "Paula", "Quintino", "Rafaela", "Sérgio", "Tatiane"
    ]

    for _ in range(1000):
        nome_escolhido = random.choice(nomes)
        valor = round(random.uniform(0, 100000), 2)
        timestamp = datetime.now(timezone.utc).isoformat()

        data = {
            "nome": nome_escolhido,
            "valor": valor,
            "timestamp": timestamp
        }
        

        try:
            response = kinesis.put_record(
                StreamName=stream_name,
                Data=json.dumps(data).encode("utf-8"),  
                PartitionKey='1'  
            )
            print(f"Enviado: {data} -> ShardId: {response['ShardId']}")
        except Exception as e:
            print(f"Erro ao enviar para Kinesis: {str(e)}")
        break

    return {
        'statusCode': 200,
        'body': json.dumps('Registros enviados com sucesso'),

    }
