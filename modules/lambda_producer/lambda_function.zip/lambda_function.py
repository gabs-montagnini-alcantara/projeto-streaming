import os
import boto3
import json
import random
from datetime import datetime, timezone
import time



def lambda_handler(event, context):
    kinesis = boto3.client('kinesis')
    stream_name = os.environ['KINESIS_STREAM']

    

    nomes = [
        "Ana", "Bruno", "Carlos", "Diana", "Eduardo", "Gabriel"
    ]

    for _ in range(1000):
        time.sleep(0.03)
        nome_escolhido = random.choice(nomes)
        valor = round(random.uniform(0, 100000), 2)
        timestamp = datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', '')

        mensagem = f"""
        Essa mensagem padrao de envio para aumentar a qtd de bytes finais
        {"*"*4000}
        """
        if len(nome_escolhido) < 4:
            continue
        data = {
            "nome": nome_escolhido,
            "valor": valor,
            "timestamp": timestamp,
            "texto": mensagem
        }
        

        try:
            response = kinesis.put_record(
                StreamName=stream_name,
                Data=json.dumps(data).encode("utf-8"),  
                PartitionKey='1'  
            )
            print(f"Enviado: {data} -> ShardId: {response['ShardId']}")
        except Exception as e:
            print(f"Erro ao enviar para Kinesis: {str(e)}")

    return {
        'statusCode': 200,
        'body': json.dumps('Registros enviados com sucesso'),
        'a': response

    }
